/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dpatrs;

import java.text.DecimalFormat;

/**
 *
 * @author kianjun
 */
public class DPATRS {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        PizzaFactory pf = PizzaFactory.getInstance();
        Pizza pizza;
        
        pizza = pf.getSized(4);      
        pizza = new TomatoTopping(pizza);
        pizza.makePizza();
        printPrice(pizza);
   
        pizza = pf.getSized(4);
        pizza = new PineappleTopping(pizza);
        pizza.makePizza();
        printPrice(pizza);
        
        pizza = pf.getSized(4);
        pizza = new PineappleTopping(pizza);
        pizza = new TomatoTopping(pizza);
        pizza.makePizza();
        printPrice(pizza);
        
        System.out.println("====================");

        pizza = pf.getSized(6);
        pizza = new TomatoTopping(pizza);
        pizza.bakePizza();
        printPrice(pizza);
        
        pizza = pf.getSized(6);
        pizza = new PineappleTopping(pizza);
        pizza.bakePizza();
        printPrice(pizza);
        
        pizza = pf.getSized(6);
        pizza = new TomatoTopping(pizza);
        pizza = new PineappleTopping(pizza);
        pizza.bakePizza();
        printPrice(pizza);
        
        System.out.println("====================");
        
        pizza = pf.getSized(8);
        pizza = new TomatoTopping(pizza);
        pizza.bakePizza();
        printPrice(pizza);
        
        pizza = pf.getSized(8);
        pizza = new PineappleTopping(pizza);
        pizza.bakePizza();
        printPrice(pizza);
        
        pizza = pf.getSized(8);
        pizza = new TomatoTopping(pizza);
        pizza = new PineappleTopping(pizza);
        pizza.bakePizza();
        printPrice(pizza);
    }
    
    static void printPrice(Pizza pizza) {
        DecimalFormat df = new DecimalFormat("#.##");
        System.out.println("Total Price: " + df.format(pizza.cost()) + "\n");
    }
    
}
