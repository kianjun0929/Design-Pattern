/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dpatrs;

/**
 *
 * @author kianjun
 */
public class PineappleTopping extends Topping {
    
    public PineappleTopping(Pizza pizza) {
        super(pizza);
    }
    
    @Override
    public double cost() {
        return pizza.cost() + 0.2;
    }

    @Override
    public void bakePizza() {
        pizza.bakePizza();
        System.out.println(" with Pineapple");
    }
    
}
