/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dpatrs;

/**
 *
 * @author kianjun
 */
public abstract class Topping extends Pizza {
    public Pizza pizza;
    
    public Topping() {}
    
    public Topping(Pizza pizza) {
        this.pizza = pizza;
    }

}
