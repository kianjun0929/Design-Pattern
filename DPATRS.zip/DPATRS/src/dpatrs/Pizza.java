/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dpatrs;

/**
 *
 * @author kianjun
 */
public abstract class Pizza {
    private int slice;
    public void setSize(int slice) { this.slice = slice; }
    public int getSlice() {
        return this.slice;
    }
    public abstract double cost();
    public void bakePizza(){
        System.out.println("Baking the " + this.getSlice() + " sizes of pizza ");
    }
    public void makePizza() {
        this.bakePizza();
    }
}
