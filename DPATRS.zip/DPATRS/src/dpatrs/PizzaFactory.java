/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dpatrs;

/**
 *
 * @author kianjun
 */
public class PizzaFactory {
    private static PizzaFactory pizzaFactory;
    
    private PizzaFactory() { }
    
    //Singleton
    public static PizzaFactory getInstance() {
        if(pizzaFactory == null)
            return new PizzaFactory();
        return pizzaFactory;
    }
    
    public Pizza getSized(int choice) {
        if(choice == 4) 
            return new SmallSized(choice);
        else if(choice == 6)
            return new MediumSized(choice);
        else if(choice == 8) 
            return new LargeSized(choice);
        return null;
    }
}
