/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dpatss;

/**
 *
 * @author kianjun
 */
public class SmallSizedPizzaWithTomatoAndPineapple extends SmallSizedPizza {
    
    @Override
    public double cost() {
        return 10.40;
    }

    @Override
    public void bakePizza() {
        super.bakePizza();
        System.out.println(" with Tomato");
        System.out.println(" with Pineapple");
    }
}