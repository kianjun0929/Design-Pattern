/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dpatss;

/**
 *
 * @author kianjun
 */
public abstract class Pizza {

    protected int slice;

    protected void makePizza() {
        bakePizza();
    }

    protected void setSize(int slice) {
        this.slice = slice;
    }

    protected abstract double cost();

    protected void bakePizza() {
        System.out.println("Baking the " + this.slice + " size of pizza");
    }
}
