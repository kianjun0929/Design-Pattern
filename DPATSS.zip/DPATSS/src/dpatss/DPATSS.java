/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package dpatss;
/**
 *
 * @author kianjun
 */
public class DPATSS {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Pizza smallPizzaWTomato = new SmallSizedPizzaWithTomato();
        smallPizzaWTomato.bakePizza();
        print(smallPizzaWTomato);
        
        System.out.println("");
        
        Pizza smallPizzaWPineapple = new SmallSizedPizzaWithPineapple();
        smallPizzaWPineapple.bakePizza();
        print(smallPizzaWPineapple);
        
        System.out.println("");
        
        Pizza smallPizzaWTomatoAndPineapple = new SmallSizedPizzaWithTomatoAndPineapple();
        smallPizzaWTomatoAndPineapple.bakePizza();
        print(smallPizzaWTomatoAndPineapple);
        
        System.out.println("");
        
        System.out.println("=== === === ===");
        
        Pizza mediumPizzaWTomato = new MediumSizedPizzaWithTomato();
        mediumPizzaWTomato.bakePizza();
        print(mediumPizzaWTomato);
        
        System.out.println("");
        
        Pizza mediumPizzaWPineapple = new MediumSizedPizzaWithPineapple();
        mediumPizzaWPineapple.bakePizza();
        print(mediumPizzaWPineapple);
        
        System.out.println("");
        
        Pizza mediumPizzaWTomatoAndPineapple = new MediumSizedPizzaWithTomatoAndPineapple();
        mediumPizzaWTomatoAndPineapple.bakePizza();
        print(mediumPizzaWTomatoAndPineapple);
        
        System.out.println("");
        
        System.out.println("=== === === ===");
        
        Pizza largePizzaWTomato = new LargeSizedPizzaWithTomato();
        largePizzaWTomato.bakePizza();
        print(largePizzaWTomato);
        
        System.out.println("");
        
        Pizza largePizzaWPineapple = new LargeSizedPizzaWithPineapple();
        largePizzaWPineapple.bakePizza();
        print(largePizzaWPineapple);
        
        System.out.println("");
        
        Pizza largePizzaWTomatoAndPineapple = new LargeSizedPizzaWithTomatoAndPineapple();
        largePizzaWTomatoAndPineapple.bakePizza();
        print(largePizzaWTomatoAndPineapple);
        
    }
    
    static void print(Pizza pizza) {
        System.out.println("Total price: " + pizza.cost());
    }
    
}
