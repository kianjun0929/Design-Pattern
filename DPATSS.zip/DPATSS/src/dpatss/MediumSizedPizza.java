/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dpatss;

/**
 *
 * @author kianjun
 */
public class MediumSizedPizza extends Pizza {

    public MediumSizedPizza() {
        super.setSize(6);
    }

    @Override
    public double cost() {
        return 12.0;
    }
    
    @Override
    protected void bakePizza() {
        System.out.println("Baking the " + this.slice + " sizes of pizza");
    }
    
}
